from Table1 import hello

def test_hello():
    assert hello("World") == "Hello, World!"